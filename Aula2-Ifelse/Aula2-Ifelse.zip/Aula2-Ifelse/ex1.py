num1 = int(input("Digite o número 1:"))
num2 = int(input("Digite o número 2:"))

if num1 > num2 :
    print(f"O número {num1} é maior que {num2}")
else:
    print(f"O número {num2} é maior que {num1}")